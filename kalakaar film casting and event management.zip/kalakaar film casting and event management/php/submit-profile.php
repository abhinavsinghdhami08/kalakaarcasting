<?php
// Profile submission handler
header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Function to send JSON response
function sendResponse($success, $message, $data = null) {
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendResponse(false, 'Invalid request method');
}

// Create uploads directory if it doesn't exist
$uploads_dir = __DIR__ . '/uploads/profiles/';
if (!file_exists($uploads_dir)) {
    mkdir($uploads_dir, 0755, true);
}

// Create logs directory if it doesn't exist
$logs_dir = __DIR__ . '/logs/';
if (!file_exists($logs_dir)) {
    mkdir($logs_dir, 0755, true);
}

// Validate required fields
$required_fields = [
    'firstName', 'lastName', 'email', 'phone', 'dob', 'gender', 
    'location', 'category', 'experience', 'skills', 'languages', 'bio', 'availability'
];

foreach ($required_fields as $field) {
    if (empty($_POST[$field])) {
        sendResponse(false, ucfirst($field) . ' is required');
    }
}

// Validate email
if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
    sendResponse(false, 'Invalid email address');
}

// Validate phone
$phone = preg_replace('/\D/', '', $_POST['phone']);
if (strlen($phone) < 10) {
    sendResponse(false, 'Invalid phone number');
}

// Validate date of birth (must be at least 18 years old)
$dob = new DateTime($_POST['dob']);
$today = new DateTime();
$age = $today->diff($dob)->y;
if ($age < 18) {
    sendResponse(false, 'You must be at least 18 years old to submit a profile');
}

// Sanitize input data
$sanitized_data = [];
foreach ($_POST as $key => $value) {
    if (is_array($value)) {
        $sanitized_data[$key] = array_map('htmlspecialchars', $value);
    } else {
        $sanitized_data[$key] = htmlspecialchars($value);
    }
}

// Handle file uploads
$uploaded_files = [];
$profile_photo_path = '';
$portfolio_photos_paths = [];

// Handle profile photo
if (isset($_FILES['profilePhoto']) && $_FILES['profilePhoto']['error'] === UPLOAD_ERR_OK) {
    $profile_photo = $_FILES['profilePhoto'];
    
    // Validate file type
    $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
    if (!in_array($profile_photo['type'], $allowed_types)) {
        sendResponse(false, 'Profile photo must be a JPG or PNG image');
    }
    
    // Validate file size (5MB max)
    if ($profile_photo['size'] > 5 * 1024 * 1024) {
        sendResponse(false, 'Profile photo must be less than 5MB');
    }
    
    // Generate unique filename
    $filename = 'profile_' . time() . '_' . uniqid() . '.jpg';
    $filepath = $uploads_dir . $filename;
    
    // Move uploaded file
    if (move_uploaded_file($profile_photo['tmp_name'], $filepath)) {
        $profile_photo_path = 'uploads/profiles/' . $filename;
        
        // Create thumbnail
        createThumbnail($filepath, $uploads_dir . 'thumb_' . $filename, 200, 200);
    } else {
        sendResponse(false, 'Failed to upload profile photo');
    }
}

// Handle portfolio photos
if (isset($_FILES['portfolioPhotos'])) {
    $portfolio_photos = $_FILES['portfolioPhotos'];
    
    // Handle multiple files
    if (is_array($portfolio_photos['name'])) {
        $file_count = count($portfolio_photos['name']);
        
        for ($i = 0; $i < $file_count; $i++) {
            if ($portfolio_photos['error'][$i] === UPLOAD_ERR_OK) {
                $file = [
                    'name' => $portfolio_photos['name'][$i],
                    'type' => $portfolio_photos['type'][$i],
                    'tmp_name' => $portfolio_photos['tmp_name'][$i],
                    'error' => $portfolio_photos['error'][$i],
                    'size' => $portfolio_photos['size'][$i]
                ];
                
                // Validate file type
                if (!in_array($file['type'], ['image/jpeg', 'image/png', 'image/jpg'])) {
                    continue; // Skip invalid files
                }
                
                // Validate file size
                if ($file['size'] > 5 * 1024 * 1024) {
                    continue; // Skip oversized files
                }
                
                // Generate unique filename
                $filename = 'portfolio_' . time() . '_' . uniqid() . '.jpg';
                $filepath = $uploads_dir . $filename;
                
                // Move uploaded file
                if (move_uploaded_file($file['tmp_name'], $filepath)) {
                    $portfolio_photos_paths[] = 'uploads/profiles/' . $filename;
                    
                    // Create thumbnail
                    createThumbnail($filepath, $uploads_dir . 'thumb_' . $filename, 200, 200);
                }
            }
        }
    }
}

// Generate unique submission ID
$submission_id = 'KLK' . date('Y') . strtoupper(uniqid());

// Prepare data for storage
$profile_data = [
    'submission_id' => $submission_id,
    'submission_date' => date('Y-m-d H:i:s'),
    'personal_info' => [
        'first_name' => $sanitized_data['firstName'],
        'last_name' => $sanitized_data['lastName'],
        'email' => $sanitized_data['email'],
        'phone' => $sanitized_data['phone'],
        'dob' => $sanitized_data['dob'],
        'gender' => $sanitized_data['gender'],
        'location' => $sanitized_data['location']
    ],
    'professional_info' => [
        'category' => $sanitized_data['category'],
        'experience' => $sanitized_data['experience'],
        'skills' => $sanitized_data['skills'],
        'languages' => $sanitized_data['languages'],
        'bio' => $sanitized_data['bio']
    ],
    'physical_attributes' => [
        'height' => isset($sanitized_data['height']) ? $sanitized_data['height'] : '',
        'weight' => isset($sanitized_data['weight']) ? $sanitized_data['weight'] : '',
        'eye_color' => isset($sanitized_data['eyeColor']) ? $sanitized_data['eyeColor'] : '',
        'hair_color' => isset($sanitized_data['hairColor']) ? $sanitized_data['hairColor'] : ''
    ],
    'portfolio' => [
        'profile_photo' => $profile_photo_path,
        'portfolio_photos' => $portfolio_photos_paths,
        'showreel' => isset($sanitized_data['showreel']) ? $sanitized_data['showreel'] : '',
        'social_media' => isset($sanitized_data['socialMedia']) ? $sanitized_data['socialMedia'] : ''
    ],
    'availability' => [
        'status' => $sanitized_data['availability'],
        'work_types' => isset($sanitized_data['workTypes']) ? explode(',', $sanitized_data['workTypes']) : []
    ],
    'preferences' => [
        'newsletter' => isset($sanitized_data['newsletter']) ? $sanitized_data['newsletter'] : 'off'
    ],
    'status' => 'pending_review',
    'ip_address' => $_SERVER['REMOTE_ADDR']
];

// Save profile data to JSON file
$profiles_file = __DIR__ . '/data/profiles.json';
$profiles = [];

if (file_exists($profiles_file)) {
    $profiles = json_decode(file_get_contents($profiles_file), true) ?: [];
}

$profiles[] = $profile_data;

// Create data directory if it doesn't exist
$data_dir = __DIR__ . '/data/';
if (!file_exists($data_dir)) {
    mkdir($data_dir, 0755, true);
}

file_put_contents($profiles_file, json_encode($profiles, JSON_PRETTY_PRINT));

// Log the submission
logProfileSubmission($profile_data);

// Send notification emails
sendAdminNotification($profile_data);
sendUserConfirmation($profile_data);

// Send response
sendResponse(true, 'Profile submitted successfully! Your submission ID is ' . $submission_id . '. We will review your profile and contact you within 7-10 working days.');

// Function to create thumbnail
function createThumbnail($source, $destination, $width, $height) {
    $info = getimagesize($source);
    
    if ($info['mime'] == 'image/jpeg') {
        $source_image = imagecreatefromjpeg($source);
    } elseif ($info['mime'] == 'image/png') {
        $source_image = imagecreatefrompng($source);
    } else {
        return false;
    }
    
    $source_width = $info[0];
    $source_height = $info[1];
    
    // Calculate aspect ratio
    $aspect_ratio = $source_width / $source_height;
    
    if ($width / $height > $aspect_ratio) {
        $width = $height * $aspect_ratio;
    } else {
        $height = $width / $aspect_ratio;
    }
    
    $thumbnail = imagecreatetruecolor($width, $height);
    
    // Resize and crop
    imagecopyresampled($thumbnail, $source_image, 0, 0, 0, 0, $width, $height, $source_width, $source_height);
    
    // Save thumbnail
    if ($info['mime'] == 'image/jpeg') {
        imagejpeg($thumbnail, $destination, 85);
    } else {
        imagepng($thumbnail, $destination, 8);
    }
    
    imagedestroy($source_image);
    imagedestroy($thumbnail);
    
    return true;
}

// Log profile submission
function logProfileSubmission($profile_data) {
    $log_entry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'submission_id' => $profile_data['submission_id'],
        'name' => $profile_data['personal_info']['first_name'] . ' ' . $profile_data['personal_info']['last_name'],
        'email' => $profile_data['personal_info']['email'],
        'category' => $profile_data['professional_info']['category'],
        'ip' => $profile_data['ip_address']
    ];
    
    $log_file = __DIR__ . '/logs/profile_submissions.json';
    $logs = [];
    
    if (file_exists($log_file)) {
        $logs = json_decode(file_get_contents($log_file), true) ?: [];
    }
    
    $logs[] = $log_entry;
    
    // Keep only last 100 entries
    if (count($logs) > 100) {
        $logs = array_slice($logs, -100);
    }
    
    file_put_contents($log_file, json_encode($logs, JSON_PRETTY_PRINT));
}

// Send admin notification
function sendAdminNotification($profile_data) {
    $to = 'info@kalakaar-casting.com'; // Replace with actual admin email
    $subject = 'New Profile Submission - ' . $profile_data['submission_id'];
    $from = 'noreply@kalakaar-casting.com';
    $headers = "From: Kalakaar Website <$from>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    
    $name = $profile_data['personal_info']['first_name'] . ' ' . $profile_data['personal_info']['last_name'];
    $email = $profile_data['personal_info']['email'];
    $phone = $profile_data['personal_info']['phone'];
    $category = $profile_data['professional_info']['category'];
    $experience = $profile_data['professional_info']['experience'];
    $location = $profile_data['personal_info']['location'];
    
    $email_template = "
<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>New Profile Submission</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #FF6B35, #F7931E); color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background: #f9f9f9; }
        .field { margin-bottom: 15px; }
        .label { font-weight: bold; color: #FF6B35; }
        .btn { display: inline-block; padding: 10px 20px; background: #FF6B35; color: white; text-decoration: none; border-radius: 5px; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
    </style>
</head>
<body>
    <div class='container'>
        <div class='header'>
            <h2>New Profile Submission</h2>
            <p>Submission ID: {$profile_data['submission_id']}</p>
        </div>
        <div class='content'>
            <div class='field'>
                <span class='label'>Name:</span> $name
            </div>
            <div class='field'>
                <span class='label'>Email:</span> $email
            </div>
            <div class='field'>
                <span class='label'>Phone:</span> $phone
            </div>
            <div class='field'>
                <span class='label'>Location:</span> $location
            </div>
            <div class='field'>
                <span class='label'>Category:</span> $category
            </div>
            <div class='field'>
                <span class='label'>Experience:</span> $experience
            </div>
            <div class='field'>
                <span class='label'>Submission Date:</span> {$profile_data['submission_date']}
            </div>
            
            <p><a href='#' class='btn'>View Full Profile</a></p>
            <p><small>Please log in to the admin panel to review this submission.</small></p>
        </div>
        <div class='footer'>
            <p>This email was sent from the Kalakaar website profile submission system.</p>
        </div>
    </div>
</body>
</html>";
    
    mail($to, $subject, $email_template, $headers);
}

// Send user confirmation
function sendUserConfirmation($profile_data) {
    $to = $profile_data['personal_info']['email'];
    $subject = 'Profile Submission Confirmation - Kalakaar';
    $from = 'noreply@kalakaar-casting.com';
    $headers = "From: Kalakaar <$from>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    
    $name = $profile_data['personal_info']['first_name'];
    $submission_id = $profile_data['submission_id'];
    
    $email_template = "
<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>Profile Submission Confirmation</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #FF6B35, #F7931E); color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background: #f9f9f9; }
        .submission-id { background: #f0f0f0; padding: 10px; text-align: center; font-weight: bold; margin: 15px 0; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
    </style>
</head>
<body>
    <div class='container'>
        <div class='header'>
            <h2>Profile Submitted Successfully!</h2>
        </div>
        <div class='content'>
            <p>Dear $name,</p>
            <p>Thank you for submitting your profile to Kalakaar Film Casting & Event Management. We have received your application and our team will review it carefully.</p>
            
            <div class='submission-id'>
                Submission ID: $submission_id
            </div>
            
            <p><strong>What happens next?</strong></p>
            <ul>
                <li>Our team will review your profile and portfolio within 7-10 working days</li>
                <li>If your profile matches our current requirements, we will contact you for an audition or interview</li>
                <li>Selected profiles will be added to our talent database for future opportunities</li>
            </ul>
            
            <p><strong>Important:</strong> Please save your submission ID for future reference.</p>
            
            <p>If you have any questions or need to update your information, please contact us at info@kalakaar-casting.com with your submission ID.</p>
            
            <p>Best regards,<br>
            The Kalakaar Team</p>
        </div>
        <div class='footer'>
            <p>Kalakaar Film Casting & Event Management<br>
            123 Film Nagar, Andheri West, Mumbai<br>
            Phone: +91 98765 43210<br>
            Email: info@kalakaar-casting.com</p>
        </div>
    </div>
</body>
</html>";
    
    mail($to, $subject, $email_template, $headers);
}
?>
