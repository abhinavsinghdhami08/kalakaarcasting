<?php
// Profile Submission Handler with Database Integration
define('API_MODE', true);
require_once '../config/database.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Invalid request method', null, 405);
}

try {
    // Start transaction
    $db = getDB();
    $db->beginTransaction();
    
    // Generate unique submission ID
    $submissionId = generateUniqueId('KLK');
    
    // Validate required fields
    $requiredFields = [
        'firstName', 'lastName', 'email', 'phone', 'dob', 'gender', 
        'location', 'category', 'experience', 'skills', 'languages', 'bio', 'availability'
    ];
    
    validateRequired($_POST, $requiredFields);
    
    // Sanitize and validate input data
    $personalInfo = [
        'first_name' => sanitize($_POST['firstName']),
        'last_name' => sanitize($_POST['lastName']),
        'email' => sanitize($_POST['email']),
        'phone' => sanitize($_POST['phone']),
        'dob' => sanitize($_POST['dob']),
        'gender' => sanitize($_POST['gender']),
        'location' => sanitize($_POST['location'])
    ];
    
    $professionalInfo = [
        'category' => sanitize($_POST['category']),
        'experience' => sanitize($_POST['experience']),
        'skills' => sanitize($_POST['skills']),
        'languages' => sanitize($_POST['languages']),
        'bio' => sanitize($_POST['bio'])
    ];
    
    $physicalAttributes = [
        'height' => isset($_POST['height']) ? (int)$_POST['height'] : null,
        'weight' => isset($_POST['weight']) ? (int)$_POST['weight'] : null,
        'eye_color' => isset($_POST['eyeColor']) ? sanitize($_POST['eyeColor']) : null,
        'hair_color' => isset($_POST['hairColor']) ? sanitize($_POST['hairColor']) : null
    ];
    
    $availability = [
        'availability' => sanitize($_POST['availability']),
        'newsletter' => isset($_POST['newsletter']) ? 1 : 0
    ];
    
    // Validate email
    if (!validateEmail($personalInfo['email'])) {
        jsonResponse(false, 'Invalid email address', null, 400);
    }
    
    // Validate phone
    if (!validatePhone($personalInfo['phone'])) {
        jsonResponse(false, 'Invalid phone number', null, 400);
    }
    
    // Validate date of birth (must be at least 18 years old)
    $dob = new DateTime($personalInfo['dob']);
    $today = new DateTime();
    $age = $today->diff($dob)->y;
    if ($age < 18) {
        jsonResponse(false, 'You must be at least 18 years old to submit a profile', null, 400);
    }
    
    // Handle file uploads
    $portfolioData = [
        'profile_photo' => '',
        'portfolio_photos' => '',
        'showreel' => isset($_POST['showreel']) ? sanitize($_POST['showreel']) : '',
        'social_media' => isset($_POST['socialMedia']) ? sanitize($_POST['socialMedia']) : ''
    ];
    
    // Handle profile photo
    if (isset($_FILES['profilePhoto']) && $_FILES['profilePhoto']['error'] === UPLOAD_ERR_OK) {
        $uploadResult = handleFileUpload($_FILES['profilePhoto'], 'profiles');
        $portfolioData['profile_photo'] = $uploadResult['path'];
    }
    
    // Handle portfolio photos
    if (isset($_FILES['portfolioPhotos'])) {
        $portfolioPaths = [];
        $files = $_FILES['portfolioPhotos'];
        
        if (is_array($files['name'])) {
            $fileCount = count($files['name']);
            for ($i = 0; $i < $fileCount; $i++) {
                if ($files['error'][$i] === UPLOAD_ERR_OK) {
                    $file = [
                        'name' => $files['name'][$i],
                        'type' => $files['type'][$i],
                        'tmp_name' => $files['tmp_name'][$i],
                        'error' => $files['error'][$i],
                        'size' => $files['size'][$i]
                    ];
                    
                    try {
                        $uploadResult = handleFileUpload($file, 'profiles');
                        $portfolioPaths[] = $uploadResult['path'];
                    } catch (Exception $e) {
                        // Log error but continue processing
                        error_log("Portfolio photo upload failed: " . $e->getMessage());
                    }
                }
            }
        }
        
        $portfolioData['portfolio_photos'] = implode(',', $portfolioPaths);
    }
    
    // Handle work types
    $workTypes = isset($_POST['workTypes']) ? sanitize($_POST['workTypes']) : '';
    
    // Prepare data for database insertion
    $profileData = array_merge([
        'submission_id' => $submissionId,
        'ip_address' => $_SERVER['REMOTE_ADDR'],
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'status' => 'pending_review',
        'work_types' => $workTypes
    ], $personalInfo, $professionalInfo, $physicalAttributes, $availability, $portfolioData);
    
    // Insert profile into database
    $profileId = $db->insert('profiles', $profileData);
    
    // Log activity
    logActivity('PROFILE_SUBMISSION', "Submission ID: $submissionId, Name: {$personalInfo['first_name']} {$personalInfo['last_name']}");
    
    // Commit transaction
    $db->commit();
    
    // Send notifications
    $adminNotificationSent = sendProfileNotification($profileData);
    $userConfirmationSent = sendProfileConfirmation($profileData);
    
    jsonResponse(true, 'Profile submitted successfully! Your submission ID is ' . $submissionId . '. We will review your profile and contact you within 7-10 working days.', [
        'submission_id' => $submissionId,
        'profile_id' => $profileId,
        'admin_notification_sent' => $adminNotificationSent,
        'user_confirmation_sent' => $userConfirmationSent
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    if (isset($db)) {
        $db->rollback();
    }
    
    error_log("Profile submission error: " . $e->getMessage());
    jsonResponse(false, 'An error occurred while processing your profile submission', null, 500);
}

/**
 * Send email notification to admin
 */
function sendProfileNotification($data) {
    $subject = 'New Profile Submission - ' . $data['submission_id'];
    
    $name = $data['first_name'] . ' ' . $data['last_name'];
    $category = ucfirst($data['category']);
    $experience = $data['experience'];
    $location = $data['location'];
    
    $message = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <title>New Profile Submission</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #FF6B35, #F7931E); color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f9f9f9; }
            .field { margin-bottom: 15px; }
            .label { font-weight: bold; color: #FF6B35; }
            .btn { display: inline-block; padding: 10px 20px; background: #FF6B35; color: white; text-decoration: none; border-radius: 5px; }
            .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>New Profile Submission</h2>
                <p>Submission ID: {$data['submission_id']}</p>
            </div>
            <div class='content'>
                <div class='field'>
                    <span class='label'>Name:</span> $name
                </div>
                <div class='field'>
                    <span class='label'>Email:</span> {$data['email']}
                </div>
                <div class='field'>
                    <span class='label'>Phone:</span> {$data['phone']}
                </div>
                <div class='field'>
                    <span class='label'>Location:</span> $location
                </div>
                <div class='field'>
                    <span class='label'>Category:</span> $category
                </div>
                <div class='field'>
                    <span class='label'>Experience:</span> $experience
                </div>
                <div class='field'>
                    <span class='label'>Age:</span> " . calculateAge($data['dob']) . " years
                </div>
                <div class='field'>
                    <span class='label'>Submission Date:</span> " . date('Y-m-d H:i:s') . "
                </div>
                
                <p><strong>Skills:</strong><br>{$data['skills']}</p>
                <p><strong>Bio:</strong><br>" . nl2br($data['bio']) . "</p>";
    
    if (!empty($data['profile_photo'])) {
        $message .= "<p><strong>Profile Photo:</strong> Available</p>";
    }
    
    $message .= "
                <p><a href='#' class='btn'>View Full Profile in Admin Panel</a></p>
                <p><small>Please log in to the admin panel to review this submission.</small></p>
            </div>
            <div class='footer'>
                <p>This email was sent from the " . APP_NAME . " profile submission system.</p>
            </div>
        </div>
    </body>
    </html>";
    
    return sendEmail(APP_EMAIL, $subject, $message);
}

/**
 * Send confirmation email to user
 */
function sendProfileConfirmation($data) {
    $subject = 'Profile Submission Confirmation - ' . APP_NAME;
    $name = $data['first_name'];
    
    $message = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <title>Profile Submission Confirmation</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #FF6B35, #F7931E); color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f9f9f9; }
            .submission-id { background: #f0f0f0; padding: 15px; text-align: center; font-weight: bold; margin: 15px 0; border-radius: 5px; }
            .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>Profile Submitted Successfully!</h2>
            </div>
            <div class='content'>
                <p>Dear $name,</p>
                <p>Thank you for submitting your profile to " . APP_NAME . ". We have received your application and our team will review it carefully.</p>
                
                <div class='submission-id'>
                    Submission ID: {$data['submission_id']}
                </div>
                
                <p><strong>What happens next?</strong></p>
                <ul>
                    <li>Our team will review your profile and portfolio within 7-10 working days</li>
                    <li>If your profile matches our current requirements, we will contact you for an audition or interview</li>
                    <li>Selected profiles will be added to our talent database for future opportunities</li>
                </ul>
                
                <p><strong>Important:</strong> Please save your submission ID for future reference.</p>
                
                <p>If you have any questions or need to update your information, please contact us with your submission ID.</p>
                
                <p>Best regards,<br>
                The " . APP_NAME . " Team</p>
            </div>
            <div class='footer'>
                <p>" . APP_NAME . "<br>
                " . APP_URL . "<br>
                Email: " . APP_EMAIL . "</p>
            </div>
        </div>
    </body>
    </html>";
    
    return sendEmail($data['email'], $subject, $message);
}

/**
 * Calculate age from date of birth
 */
function calculateAge($dob) {
    $birthDate = new DateTime($dob);
    $today = new DateTime();
    return $today->diff($birthDate)->y;
}
?>
