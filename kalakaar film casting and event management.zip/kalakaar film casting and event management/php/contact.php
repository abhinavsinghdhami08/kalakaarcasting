<?php
// Contact form handler
header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Function to send JSON response
function sendResponse($success, $message, $data = null) {
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendResponse(false, 'Invalid request method');
}

// Get JSON input
$json_input = file_get_contents('php://input');
$data = json_decode($json_input, true);

if (!$data) {
    sendResponse(false, 'Invalid JSON data');
}

// Validate required fields
$required_fields = ['name', 'email', 'message'];
foreach ($required_fields as $field) {
    if (empty($data[$field])) {
        sendResponse(false, ucfirst($field) . ' is required');
    }
}

// Validate email
if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
    sendResponse(false, 'Invalid email address');
}

// Sanitize input
$name = filter_var($data['name'], FILTER_SANITIZE_STRING);
$email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);
$phone = isset($data['phone']) ? filter_var($data['phone'], FILTER_SANITIZE_STRING) : '';
$message = filter_var($data['message'], FILTER_SANITIZE_STRING);

// Email configuration
$to = 'info@kalakaar-casting.com'; // Replace with actual email
$subject = 'New Contact Form Submission - Kalakaar';
$from = 'noreply@kalakaar-casting.com';
$headers = "From: Kalakaar Website <$from>\r\n";
$headers .= "Reply-To: $email\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";

// Create email template
$email_template = "
<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>New Contact Form Submission</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #FF6B35, #F7931E); color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background: #f9f9f9; }
        .field { margin-bottom: 15px; }
        .label { font-weight: bold; color: #FF6B35; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
    </style>
</head>
<body>
    <div class='container'>
        <div class='header'>
            <h2>New Contact Form Submission</h2>
            <p>Kalakaar Film Casting & Event Management</p>
        </div>
        <div class='content'>
            <div class='field'>
                <span class='label'>Name:</span> $name
            </div>
            <div class='field'>
                <span class='label'>Email:</span> $email
            </div>";
            
if (!empty($phone)) {
    $email_template .= "
            <div class='field'>
                <span class='label'>Phone:</span> $phone
            </div>";
}

$email_template .= "
            <div class='field'>
                <span class='label'>Message:</span><br>
                " . nl2br($message) . "
            </div>
        </div>
        <div class='footer'>
            <p>This email was sent from the Kalakaar website contact form.</p>
            <p>Date: " . date('Y-m-d H:i:s') . "</p>
        </div>
    </div>
</body>
</html>";

// Send email
try {
    $mail_sent = mail($to, $subject, $email_template, $headers);
    
    if ($mail_sent) {
        // Log the submission (optional)
        logContactSubmission($name, $email, $phone, $message);
        
        // Send auto-reply to user
        sendAutoReply($name, $email);
        
        sendResponse(true, 'Message sent successfully! We will get back to you soon.');
    } else {
        sendResponse(false, 'Failed to send email. Please try again later.');
    }
} catch (Exception $e) {
    error_log('Contact form error: ' . $e->getMessage());
    sendResponse(false, 'An error occurred while sending your message.');
}

// Log contact submission
function logContactSubmission($name, $email, $phone, $message) {
    $log_entry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
        'message' => $message,
        'ip' => $_SERVER['REMOTE_ADDR']
    ];
    
    $log_file = __DIR__ . '/logs/contact_submissions.json';
    $logs = [];
    
    if (file_exists($log_file)) {
        $logs = json_decode(file_get_contents($log_file), true) ?: [];
    }
    
    $logs[] = $log_entry;
    
    // Keep only last 100 entries
    if (count($logs) > 100) {
        $logs = array_slice($logs, -100);
    }
    
    file_put_contents($log_file, json_encode($logs, JSON_PRETTY_PRINT));
}

// Send auto-reply to user
function sendAutoReply($name, $email) {
    $subject = 'Thank you for contacting Kalakaar';
    $from = 'noreply@kalakaar-casting.com';
    $headers = "From: Kalakaar <$from>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    
    $auto_reply = "
<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>Thank you for contacting Kalakaar</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #FF6B35, #F7931E); color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background: #f9f9f9; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
    </style>
</head>
<body>
    <div class='container'>
        <div class='header'>
            <h2>Thank You for Contacting Kalakaar!</h2>
        </div>
        <div class='content'>
            <p>Dear $name,</p>
            <p>Thank you for reaching out to Kalakaar Film Casting & Event Management. We have received your message and our team will get back to you within 24-48 hours.</p>
            <p><strong>What happens next?</strong></p>
            <ul>
                <li>Our team will review your inquiry</li>
                <li>We'll respond to your email or call you back</li>
                <li>We'll provide the information or assistance you need</li>
            </ul>
            <p>If you have any urgent questions, please feel free to call us at +91 98765 43210.</p>
            <p>Best regards,<br>
            The Kalakaar Team</p>
        </div>
        <div class='footer'>
            <p>Kalakaar Film Casting & Event Management<br>
            123 Film Nagar, Andheri West, Mumbai<br>
            Phone: +91 98765 43210<br>
            Email: info@kalakaar-casting.com</p>
        </div>
    </div>
</body>
</html>";
    
    mail($email, $subject, $auto_reply, $headers);
}
?>
