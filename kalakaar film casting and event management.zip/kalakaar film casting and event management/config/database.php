<?php
// Database Configuration for Kalakaar Website
// This file contains database connection settings and utility functions

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'kalakaar_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Application Configuration
define('APP_NAME', 'Kalakaar Film Casting & Event Management');
define('APP_EMAIL', 'info@kalakaar-casting.com');
define('APP_URL', 'https://kalakaar-casting.com');

// File Upload Configuration
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png']);

// Email Configuration
define('SMTP_HOST', 'localhost');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', '');
define('SMTP_PASSWORD', '');
define('SMTP_ENCRYPTION', 'tls');

// Security Configuration
define('HASH_ALGO', 'sha256');
define('SESSION_LIFETIME', 3600); // 1 hour

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Ensure required directories exist (prevents warnings/fatal issues on fresh deploys)
$__kalakaar_log_dir = __DIR__ . '/../logs';
if (!file_exists($__kalakaar_log_dir)) {
    @mkdir($__kalakaar_log_dir, 0755, true);
}

$__kalakaar_upload_dir = __DIR__ . '/../uploads';
if (!file_exists($__kalakaar_upload_dir)) {
    @mkdir($__kalakaar_upload_dir, 0755, true);
}

if (!file_exists($__kalakaar_upload_dir . '/profiles')) {
    @mkdir($__kalakaar_upload_dir . '/profiles', 0755, true);
}

if (!file_exists($__kalakaar_upload_dir . '/site')) {
    @mkdir($__kalakaar_upload_dir . '/site', 0755, true);
}

ini_set('error_log', __DIR__ . '/../logs/php_errors.log');

/**
 * Database Connection Class
 */
class Database {
    private static $instance = null;
    private $connection;
    
    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_PERSISTENT => true
            ];
            
            $this->connection = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            throw new Exception("Database connection failed");
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    public function query($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            error_log("Query failed: " . $e->getMessage() . " SQL: " . $sql);
            throw new Exception("Database query failed");
        }
    }
    
    public function insert($table, $data) {
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        $values = array_values($data);
        
        $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";
        $this->query($sql, $values);
        
        return $this->connection->lastInsertId();
    }
    
    public function update($table, $data, $where, $whereParams = []) {
        $setClause = [];
        $values = [];
        
        foreach ($data as $column => $value) {
            $setClause[] = "$column = ?";
            $values[] = $value;
        }
        
        $setClause = implode(', ', $setClause);
        $values = array_merge($values, $whereParams);
        
        $sql = "UPDATE $table SET $setClause WHERE $where";
        $stmt = $this->query($sql, $values);
        
        return $stmt->rowCount();
    }
    
    public function delete($table, $where, $params = []) {
        $sql = "DELETE FROM $table WHERE $where";
        $stmt = $this->query($sql, $params);
        
        return $stmt->rowCount();
    }
    
    public function beginTransaction() {
        return $this->connection->beginTransaction();
    }
    
    public function commit() {
        return $this->connection->commit();
    }
    
    public function rollback() {
        return $this->connection->rollback();
    }
}

/**
 * Utility Functions
 */

/**
 * Sanitize input data
 */
function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Validate email
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate phone number
 */
function validatePhone($phone) {
    $phone = preg_replace('/\D/', '', $phone);
    return strlen($phone) >= 10;
}

/**
 * Generate unique ID
 */
function generateUniqueId($prefix = 'KLK') {
    return $prefix . date('Y') . strtoupper(uniqid());
}

/**
 * Handle file upload
 */
function handleFileUpload($file, $subfolder = 'profiles') {
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('File upload error');
    }
    
    // Validate file size
    if ($file['size'] > MAX_FILE_SIZE) {
        throw new Exception('File size exceeds limit');
    }
    
    // Validate file type
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, ALLOWED_EXTENSIONS)) {
        throw new Exception('Invalid file type');
    }
    
    // Create upload directory if it doesn't exist
    $uploadDir = UPLOAD_PATH . $subfolder . '/';
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    // Generate unique filename
    $filename = uniqid() . '_' . time() . '.' . $extension;
    $filepath = $uploadDir . $filename;
    
    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        throw new Exception('Failed to move uploaded file');
    }
    
    // Create thumbnail
    $thumbnailPath = $uploadDir . 'thumb_' . $filename;
    // Do not fail uploads if GD is not available (common on some XAMPP setups)
    @createThumbnail($filepath, $thumbnailPath, 200, 200);
    
    return [
        'filename' => $filename,
        'path' => 'uploads/' . $subfolder . '/' . $filename,
        'thumbnail' => 'uploads/' . $subfolder . '/thumb_' . $filename
    ];
}

/**
 * Create thumbnail
 */
function createThumbnail($source, $destination, $width, $height) {
    if (!extension_loaded('gd')) {
        return false;
    }
    if (!function_exists('imagecreatetruecolor')) {
        return false;
    }

    $info = getimagesize($source);
    
    if (!$info) {
        return false;
    }
    
    $mime = $info['mime'];
    $sourceWidth = $info[0];
    $sourceHeight = $info[1];
    
    // Create image resource
    switch ($mime) {
        case 'image/jpeg':
            if (!function_exists('imagecreatefromjpeg')) {
                return false;
            }
            $sourceImage = imagecreatefromjpeg($source);
            break;
        case 'image/png':
            if (!function_exists('imagecreatefrompng')) {
                return false;
            }
            $sourceImage = imagecreatefrompng($source);
            break;
        default:
            return false;
    }
    
    // Calculate aspect ratio
    $aspectRatio = $sourceWidth / $sourceHeight;
    
    if ($width / $height > $aspectRatio) {
        $width = $height * $aspectRatio;
    } else {
        $height = $width / $aspectRatio;
    }
    
    // Create thumbnail
    $thumbnail = imagecreatetruecolor((int)$width, (int)$height);
    imagecopyresampled($thumbnail, $sourceImage, 0, 0, 0, 0, (int)$width, (int)$height, $sourceWidth, $sourceHeight);
    
    // Save thumbnail
    switch ($mime) {
        case 'image/jpeg':
            if (!function_exists('imagejpeg')) {
                imagedestroy($sourceImage);
                imagedestroy($thumbnail);
                return false;
            }
            imagejpeg($thumbnail, $destination, 85);
            break;
        case 'image/png':
            if (!function_exists('imagepng')) {
                imagedestroy($sourceImage);
                imagedestroy($thumbnail);
                return false;
            }
            imagepng($thumbnail, $destination, 8);
            break;
    }
    
    imagedestroy($sourceImage);
    imagedestroy($thumbnail);
    
    return true;
}

/**
 * Send email
 */
function sendEmail($to, $subject, $message, $from = null) {
    $from = $from ?: APP_EMAIL;
    $headers = [
        'From: ' . APP_NAME . ' <' . $from . '>',
        'Reply-To: ' . $from,
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8'
    ];
    
    return mail($to, $subject, $message, implode("\r\n", $headers));
}

/**
 * Log activity
 */
function logActivity($action, $details = null) {
    $logFile = __DIR__ . '/../logs/activity.log';
    $timestamp = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
    
    $logEntry = sprintf(
        "[%s] [%s] %s - %s - %s\n",
        $timestamp,
        $ip,
        $action,
        $details ?? '',
        $userAgent
    );
    
    file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
}

/**
 * JSON response helper
 */
function jsonResponse($success, $message, $data = null, $httpCode = 200) {
    http_response_code($httpCode);
    header('Content-Type: application/json');
    
    $response = [
        'success' => $success,
        'message' => $message
    ];
    
    if ($data !== null) {
        $response['data'] = $data;
    }
    
    echo json_encode($response);
    exit;
}

/**
 * Validate required fields
 */
function validateRequired($data, $required) {
    $missing = [];
    
    foreach ($required as $field) {
        if (empty($data[$field])) {
            $missing[] = $field;
        }
    }
    
    if (!empty($missing)) {
        jsonResponse(false, 'Missing required fields: ' . implode(', ', $missing), null, 400);
    }
    
    return true;
}

/**
 * Get database instance
 */
function getDB() {
    return Database::getInstance();
}

// Initialize database connection
try {
    $db = getDB();
} catch (Exception $e) {
    error_log("Database initialization failed: " . $e->getMessage());
    if (defined('API_MODE')) {
        jsonResponse(false, 'Database connection failed', null, 500);
    }
}
?>
