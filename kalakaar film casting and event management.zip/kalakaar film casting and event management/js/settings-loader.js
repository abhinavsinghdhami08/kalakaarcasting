document.addEventListener('DOMContentLoaded', function () {
    fetch('php/public-settings.php', { method: 'GET' })
        .then(function (r) { return r.json(); })
        .then(function (res) {
            if (!res || !res.success || !res.data) return;
            applySettings(res.data);
        })
        .catch(function () { });
});

function applySettings(s) {
    if (s.theme_primary) {
        document.documentElement.style.setProperty('--primary-color', s.theme_primary);
    }
    if (s.theme_secondary) {
        document.documentElement.style.setProperty('--secondary-color', s.theme_secondary);
    }

    if (s.header_name) {
        document.querySelectorAll('[data-setting="header_name"]').forEach(function (el) {
            el.textContent = s.header_name;
        });
    }

    if (s.site_name) {
        var titleEls = document.querySelectorAll('.hero-slide:first-child .hero-title');
        titleEls.forEach(function (el) { el.textContent = s.site_name; });
    }

    if (s.tagline) {
        var subEls = document.querySelectorAll('.hero-slide:first-child .hero-subtitle');
        subEls.forEach(function (el) { el.textContent = s.tagline; });
    }

    if (s.site_phone) {
        document.querySelectorAll('[data-setting="site_phone"]').forEach(function (el) {
            el.textContent = s.site_phone;
        });
    }

    if (s.site_email) {
        document.querySelectorAll('[data-setting="site_email"]').forEach(function (el) {
            el.textContent = s.site_email;
        });
    }

    if (s.site_address) {
        document.querySelectorAll('[data-setting="site_address"]').forEach(function (el) {
            el.textContent = s.site_address;
        });
    }

    setSocialLink('instagram', s.social_instagram);

    if (s.site_logo) {
        var logoImgs = document.querySelectorAll('#siteLogoImg');
        logoImgs.forEach(function (img) {
            img.src = s.site_logo;
            img.style.display = 'inline-block';
        });
    }

    if (s.site_dp) {
        var dpImg = document.getElementById('siteDpImg');
        if (dpImg) {
            dpImg.src = s.site_dp;
            dpImg.style.display = 'block';
        }
    }

    if (s.talent_showcase_items) {
        renderTalentShowcase(s.talent_showcase_items);
    }

    if (s.event_gallery_items) {
        renderEventGallery(s.event_gallery_items);
    }

    setHeroBg(0, s.hero_image_1);
    setHeroBg(1, s.hero_image_2);
    setHeroBg(2, s.hero_image_3);

    if (s.about_image) {
        var aboutImg = document.querySelector('.about-image img');
        if (aboutImg) aboutImg.src = s.about_image;
    }
}

function renderTalentShowcase(items) {
    if (!Array.isArray(items)) return;
    var grid = document.querySelector('.portfolio-grid');
    if (!grid) return;

    var mapped = items.filter(function (it) {
        return it && it.image;
    }).map(function (it) {
        return {
            image: String(it.image),
            category: 'all'
        };
    });

    if (mapped.length === 0) return;

    grid.innerHTML = '';
    mapped.forEach(function (it) {
        var item = document.createElement('div');
        item.className = 'portfolio-item active';
        item.setAttribute('data-category', 'all');

        var card = document.createElement('div');
        card.className = 'portfolio-card';

        var imgWrap = document.createElement('div');
        imgWrap.className = 'portfolio-image';
        var img = document.createElement('img');
        img.src = it.image;
        img.alt = 'Talent';
        imgWrap.appendChild(img);

        card.appendChild(imgWrap);
        item.appendChild(card);
        grid.appendChild(item);
    });
}

function renderEventGallery(items) {
    if (!Array.isArray(items)) return;
    var grid = document.querySelector('.gallery-grid');
    if (!grid) return;

    var mapped = items.filter(function (it) {
        return it && it.image;
    }).map(function (it) {
        return String(it.image);
    });

    if (mapped.length === 0) return;

    grid.innerHTML = '';
    mapped.forEach(function (src) {
        var item = document.createElement('div');
        item.className = 'gallery-item';

        var img = document.createElement('img');
        img.src = src;
        img.alt = 'Event Gallery';
        item.appendChild(img);

        var overlay = document.createElement('div');
        overlay.className = 'gallery-overlay';
        var icon = document.createElement('i');
        icon.className = 'fas fa-search-plus';
        overlay.appendChild(icon);
        item.appendChild(overlay);

        grid.appendChild(item);
    });
}

function setSocialLink(name, url) {
    if (!url) return;
    document.querySelectorAll('[data-social="' + name + '"]').forEach(function (a) {
        a.href = url;
    });
}

function setHeroBg(index, url) {
    if (!url) return;
    var slides = document.querySelectorAll('.hero-slide');
    if (!slides || !slides[index]) return;
    slides[index].style.backgroundImage = "linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('" + url + "')";
}
