<?php
require_once __DIR__ . '/includes/auth.php';

if (admin_user()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim($_POST['identifier'] ?? '');
    $password = (string)($_POST['password'] ?? '');

    if ($identifier === '' || $password === '') {
        $error = 'Please enter username/email and password.';
    } else {
        try {
            $db = getDB();
            $stmt = $db->query(
                'SELECT id, username, email, password_hash, full_name, role, is_active FROM admin_users WHERE (username = ? OR email = ?) LIMIT 1',
                [$identifier, $identifier]
            );
            $user = $stmt->fetch();

            if (!$user || (int)$user['is_active'] !== 1) {
                $error = 'Invalid login.';
            } elseif (!password_verify($password, $user['password_hash'])) {
                $error = 'Invalid login.';
            } else {
                $_SESSION['admin_user'] = [
                    'id' => (int)$user['id'],
                    'username' => $user['username'],
                    'email' => $user['email'],
                    'full_name' => $user['full_name'],
                    'role' => $user['role']
                ];

                $db->update('admin_users', ['last_login' => date('Y-m-d H:i:s')], 'id = ?', [(int)$user['id']]);

                header('Location: dashboard.php');
                exit;
            }
        } catch (Exception $e) {
            $error = 'Login failed. Check database connection.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin Login | Kalakaar</title>
    <link rel="stylesheet" href="assets/admin.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="topbar">
        <div class="wrap">
            <div class="brand">Kalakaar Admin</div>
            <div class="nav"><a href="../index.html">Back to Website</a></div>
        </div>
    </div>

    <div class="wrap">
        <div class="card" style="max-width:520px;margin:30px auto;">
            <h2 style="margin-top:0;">Login</h2>
            <p class="muted">Use your admin username/email and password.</p>

            <?php if ($error): ?>
                <div class="error"><?php echo h($error); ?></div>
            <?php endif; ?>

            <form method="post" autocomplete="off">
                <div style="margin-bottom:12px;">
                    <label class="muted" for="identifier">Username or Email</label>
                    <input class="input" id="identifier" name="identifier" type="text" value="<?php echo h($_POST['identifier'] ?? ''); ?>" required />
                </div>
                <div style="margin-bottom:16px;">
                    <label class="muted" for="password">Password</label>
                    <input class="input" id="password" name="password" type="password" required />
                </div>
                <div class="row" style="justify-content:space-between;align-items:center;">
                    <button class="btn btn-primary" type="submit">Login</button>
                    <a class="muted" href="password.php">Change Password</a>
                </div>
            </form>

            <div style="margin-top:14px;" class="muted">
                Admin URL: <code>/admin/login.php</code>
            </div>
        </div>
    </div>
</body>
</html>
