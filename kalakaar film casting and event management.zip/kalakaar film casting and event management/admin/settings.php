<?php
require_once __DIR__ . '/includes/auth.php';
require_admin();

$db = getDB();

function get_setting_value($db, $key, $default = '') {
    $stmt = $db->query('SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1', [$key]);
    $row = $stmt->fetch();
    return $row ? (string)$row['setting_value'] : $default;
}

function get_setting_json($db, $key, $default = []) {
    $raw = get_setting_value($db, $key, '');
    if ($raw === '') {
        return $default;
    }
    $decoded = json_decode((string)$raw, true);
    return is_array($decoded) ? $decoded : $default;
}

function upsert_setting($db, $key, $value, $type = 'string', $description = '', $is_public = 1) {
    $stmt = $db->query('SELECT id FROM settings WHERE setting_key = ? LIMIT 1', [$key]);
    $row = $stmt->fetch();

    $payload = [
        'setting_key' => $key,
        'setting_value' => $value,
        'setting_type' => $type,
        'description' => $description,
        'is_public' => (int)$is_public
    ];

    if ($row) {
        $db->update('settings', [
            'setting_value' => $value,
            'setting_type' => $type,
            'description' => $description,
            'is_public' => (int)$is_public
        ], 'setting_key = ?', [$key]);
        return (int)$row['id'];
    }

    return (int)$db->insert('settings', $payload);
}

$flash_success = '';
$flash_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';

    if (!verify_csrf($token)) {
        $flash_error = 'Security check failed. Please refresh and try again.';
    } else {
        try {
            $site_name = trim($_POST['site_name'] ?? '');
            $header_name = trim($_POST['header_name'] ?? '');
            $tagline = trim($_POST['tagline'] ?? '');
            $site_description = trim($_POST['site_description'] ?? '');

            $site_phone = trim($_POST['site_phone'] ?? '');
            $site_email = trim($_POST['site_email'] ?? '');
            $site_address = trim($_POST['site_address'] ?? '');

            $social_instagram = trim($_POST['social_instagram'] ?? '');

            $theme_primary = trim($_POST['theme_primary'] ?? '#FF6B35');
            $theme_secondary = trim($_POST['theme_secondary'] ?? '#F7931E');

            upsert_setting($db, 'site_name', $site_name, 'string', 'Website name', 1);
            upsert_setting($db, 'header_name', $header_name, 'string', 'Header / brand name', 1);
            upsert_setting($db, 'tagline', $tagline, 'string', 'Homepage tagline', 1);
            upsert_setting($db, 'site_description', $site_description, 'text', 'Homepage meta/intro description', 1);

            upsert_setting($db, 'site_phone', $site_phone, 'string', 'Contact phone', 1);
            upsert_setting($db, 'site_email', $site_email, 'string', 'Contact email', 1);
            upsert_setting($db, 'site_address', $site_address, 'text', 'Contact address', 1);

            upsert_setting($db, 'social_instagram', $social_instagram, 'string', 'Instagram URL', 1);

            upsert_setting($db, 'theme_primary', $theme_primary, 'string', 'Primary theme color', 1);
            upsert_setting($db, 'theme_secondary', $theme_secondary, 'string', 'Secondary theme color', 1);

            $uploads = [];

            if (isset($_FILES['site_logo']) && $_FILES['site_logo']['error'] === UPLOAD_ERR_OK) {
                $uploads['site_logo'] = handleFileUpload($_FILES['site_logo'], 'site');
                upsert_setting($db, 'site_logo', $uploads['site_logo']['path'], 'string', 'Site logo', 1);
            }

            if (isset($_FILES['site_dp']) && $_FILES['site_dp']['error'] === UPLOAD_ERR_OK) {
                $uploads['site_dp'] = handleFileUpload($_FILES['site_dp'], 'site');
                upsert_setting($db, 'site_dp', $uploads['site_dp']['path'], 'string', 'Display picture', 1);
            }

            if (isset($_FILES['hero_image_1']) && $_FILES['hero_image_1']['error'] === UPLOAD_ERR_OK) {
                $uploads['hero_image_1'] = handleFileUpload($_FILES['hero_image_1'], 'site');
                upsert_setting($db, 'hero_image_1', $uploads['hero_image_1']['path'], 'string', 'Hero image 1', 1);
            }

            if (isset($_FILES['hero_image_2']) && $_FILES['hero_image_2']['error'] === UPLOAD_ERR_OK) {
                $uploads['hero_image_2'] = handleFileUpload($_FILES['hero_image_2'], 'site');
                upsert_setting($db, 'hero_image_2', $uploads['hero_image_2']['path'], 'string', 'Hero image 2', 1);
            }

            if (isset($_FILES['hero_image_3']) && $_FILES['hero_image_3']['error'] === UPLOAD_ERR_OK) {
                $uploads['hero_image_3'] = handleFileUpload($_FILES['hero_image_3'], 'site');
                upsert_setting($db, 'hero_image_3', $uploads['hero_image_3']['path'], 'string', 'Hero image 3', 1);
            }

            if (isset($_FILES['about_image']) && $_FILES['about_image']['error'] === UPLOAD_ERR_OK) {
                $uploads['about_image'] = handleFileUpload($_FILES['about_image'], 'site');
                upsert_setting($db, 'about_image', $uploads['about_image']['path'], 'string', 'About section image', 1);
            }

            if (empty($uploads['site_logo']) && !empty($_POST['delete_site_logo'])) {
                upsert_setting($db, 'site_logo', '', 'string', 'Site logo', 1);
            }

            if (empty($uploads['site_dp']) && !empty($_POST['delete_site_dp'])) {
                upsert_setting($db, 'site_dp', '', 'string', 'Display picture', 1);
            }

            if (empty($uploads['hero_image_1']) && !empty($_POST['delete_hero_image_1'])) {
                upsert_setting($db, 'hero_image_1', '', 'string', 'Hero image 1', 1);
            }

            if (empty($uploads['hero_image_2']) && !empty($_POST['delete_hero_image_2'])) {
                upsert_setting($db, 'hero_image_2', '', 'string', 'Hero image 2', 1);
            }

            if (empty($uploads['hero_image_3']) && !empty($_POST['delete_hero_image_3'])) {
                upsert_setting($db, 'hero_image_3', '', 'string', 'Hero image 3', 1);
            }

            if (empty($uploads['about_image']) && !empty($_POST['delete_about_image'])) {
                upsert_setting($db, 'about_image', '', 'string', 'About section image', 1);
            }

            $talent_items = get_setting_json($db, 'talent_showcase_items', []);
            $event_items = get_setting_json($db, 'event_gallery_items', []);

            $remove_ids = $_POST['talent_remove'] ?? [];
            if (!is_array($remove_ids)) {
                $remove_ids = [];
            }
            if (!empty($remove_ids)) {
                $talent_items = array_values(array_filter($talent_items, function ($item) use ($remove_ids) {
                    $id = isset($item['id']) ? (string)$item['id'] : '';
                    return $id === '' ? true : !in_array($id, $remove_ids, true);
                }));
            }

            if (isset($_FILES['talent_images'])) {
                $f = $_FILES['talent_images'];
                if (isset($f['name']) && is_array($f['name'])) {
                    $count = count($f['name']);
                    for ($i = 0; $i < $count; $i++) {
                        $single = [
                            'name' => $f['name'][$i] ?? '',
                            'type' => $f['type'][$i] ?? '',
                            'tmp_name' => $f['tmp_name'][$i] ?? '',
                            'error' => $f['error'][$i] ?? UPLOAD_ERR_NO_FILE,
                            'size' => $f['size'][$i] ?? 0
                        ];

                        if ((int)$single['error'] !== UPLOAD_ERR_OK) {
                            continue;
                        }

                        $up = handleFileUpload($single, 'site');
                        $talent_items[] = [
                            'id' => uniqid('tal_', true),
                            'category' => 'all',
                            'image' => $up['path']
                        ];
                    }
                }
            }

            $event_remove_ids = $_POST['event_remove'] ?? [];
            if (!is_array($event_remove_ids)) {
                $event_remove_ids = [];
            }
            if (!empty($event_remove_ids)) {
                $event_items = array_values(array_filter($event_items, function ($item) use ($event_remove_ids) {
                    $id = isset($item['id']) ? (string)$item['id'] : '';
                    return $id === '' ? true : !in_array($id, $event_remove_ids, true);
                }));
            }

            if (isset($_FILES['event_gallery_images'])) {
                $f = $_FILES['event_gallery_images'];
                if (isset($f['name']) && is_array($f['name'])) {
                    $count = count($f['name']);
                    for ($i = 0; $i < $count; $i++) {
                        $single = [
                            'name' => $f['name'][$i] ?? '',
                            'type' => $f['type'][$i] ?? '',
                            'tmp_name' => $f['tmp_name'][$i] ?? '',
                            'error' => $f['error'][$i] ?? UPLOAD_ERR_NO_FILE,
                            'size' => $f['size'][$i] ?? 0
                        ];

                        if ((int)$single['error'] !== UPLOAD_ERR_OK) {
                            continue;
                        }

                        $up = handleFileUpload($single, 'site');
                        $event_items[] = [
                            'id' => uniqid('gal_', true),
                            'image' => $up['path']
                        ];
                    }
                }
            }

            upsert_setting($db, 'talent_showcase_items', json_encode($talent_items), 'json', 'Talent showcase items', 1);
            upsert_setting($db, 'event_gallery_items', json_encode($event_items), 'json', 'Events gallery items', 1);

            $flash_success = 'Website settings updated successfully.';
        } catch (Exception $e) {
            $flash_error = 'Failed to save settings. Check uploads permissions and DB connection.';
        }
    }
}

$values = [
    'site_name' => get_setting_value($db, 'site_name', 'Kalakaar Film Casting & Event Management'),
    'header_name' => get_setting_value($db, 'header_name', 'Kalakaar'),
    'tagline' => get_setting_value($db, 'tagline', 'Discover Talent, Create Excellence'),
    'site_description' => get_setting_value($db, 'site_description', ''),

    'site_phone' => get_setting_value($db, 'site_phone', '+91 98765 43210'),
    'site_email' => get_setting_value($db, 'site_email', 'info@kalakaar-casting.com'),
    'site_address' => get_setting_value($db, 'site_address', '123 Film Nagar, Andheri West, Mumbai'),

    'social_instagram' => get_setting_value($db, 'social_instagram', 'https://instagram.com/kalakaar_film_casting'),

    'theme_primary' => get_setting_value($db, 'theme_primary', '#FF6B35'),
    'theme_secondary' => get_setting_value($db, 'theme_secondary', '#F7931E'),

    'site_logo' => get_setting_value($db, 'site_logo', ''),
    'site_dp' => get_setting_value($db, 'site_dp', ''),
    'hero_image_1' => get_setting_value($db, 'hero_image_1', ''),
    'hero_image_2' => get_setting_value($db, 'hero_image_2', ''),
    'hero_image_3' => get_setting_value($db, 'hero_image_3', ''),
    'about_image' => get_setting_value($db, 'about_image', '')
];

$talent_items = get_setting_json($db, 'talent_showcase_items', []);
$event_items = get_setting_json($db, 'event_gallery_items', []);

$user = admin_user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Website Settings | Kalakaar Admin</title>
    <link rel="stylesheet" href="assets/admin.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="topbar">
        <div class="wrap">
            <div class="brand">Kalakaar Admin</div>
            <div class="nav">
                <a href="dashboard.php">Dashboard</a>
                <a href="password.php">Change Password</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </div>

    <div class="wrap">
        <div class="row" style="justify-content:space-between;align-items:center;margin-bottom:14px;">
            <div>
                <h2 style="margin:0;">Website Settings</h2>
                <div class="muted">Update website content and media</div>
            </div>
            <div class="muted"><a href="../index.html">View Website</a></div>
        </div>

        <?php if ($flash_error): ?>
            <div class="error"><?php echo h($flash_error); ?></div>
        <?php elseif ($flash_success): ?>
            <div class="success"><?php echo h($flash_success); ?></div>
        <?php endif; ?>

        <form class="card" method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>" />

            <div class="grid">
                <div class="col-12">
                    <h3 style="margin-top:0;">Basic Info</h3>
                </div>

                <div class="col-6">
                    <label class="muted" for="header_name">Header / Brand Name</label>
                    <input class="input" id="header_name" name="header_name" value="<?php echo h($values['header_name']); ?>" />
                </div>

                <div class="col-6">
                    <label class="muted" for="site_name">Full Website Name</label>
                    <input class="input" id="site_name" name="site_name" value="<?php echo h($values['site_name']); ?>" />
                </div>

                <div class="col-12">
                    <label class="muted" for="tagline">Homepage Tagline</label>
                    <input class="input" id="tagline" name="tagline" value="<?php echo h($values['tagline']); ?>" />
                </div>

                <div class="col-12">
                    <label class="muted" for="site_description">Description</label>
                    <textarea class="input" id="site_description" name="site_description" rows="4"><?php echo h($values['site_description']); ?></textarea>
                </div>

                <div class="col-12" style="margin-top:8px;">
                    <h3>Contact</h3>
                </div>

                <div class="col-6">
                    <label class="muted" for="site_phone">Mobile / Phone</label>
                    <input class="input" id="site_phone" name="site_phone" value="<?php echo h($values['site_phone']); ?>" />
                </div>

                <div class="col-6">
                    <label class="muted" for="site_email">Email</label>
                    <input class="input" id="site_email" name="site_email" value="<?php echo h($values['site_email']); ?>" />
                </div>

                <div class="col-12">
                    <label class="muted" for="site_address">Address</label>
                    <textarea class="input" id="site_address" name="site_address" rows="3"><?php echo h($values['site_address']); ?></textarea>
                </div>

                <div class="col-12" style="margin-top:8px;">
                    <h3>Social Links</h3>
                </div>

                <div class="col-6">
                    <label class="muted" for="social_instagram">Instagram URL</label>
                    <input class="input" id="social_instagram" name="social_instagram" value="<?php echo h($values['social_instagram']); ?>" />
                </div>

                <div class="col-12" style="margin-top:8px;">
                    <h3>Theme</h3>
                </div>

                <div class="col-6">
                    <label class="muted" for="theme_primary">Primary Color</label>
                    <input class="input" id="theme_primary" name="theme_primary" value="<?php echo h($values['theme_primary']); ?>" />
                </div>

                <div class="col-6">
                    <label class="muted" for="theme_secondary">Secondary Color</label>
                    <input class="input" id="theme_secondary" name="theme_secondary" value="<?php echo h($values['theme_secondary']); ?>" />
                </div>

                <div class="col-12" style="margin-top:8px;">
                    <h3>Media Uploads</h3>
                    <div class="muted">Upload JPG/PNG. Ensure <code>uploads/site</code> is writable.</div>
                </div>

                <div class="col-6">
                    <label class="muted" for="site_logo">Logo (Navbar)</label>
                    <input class="input" id="site_logo" name="site_logo" type="file" accept="image/*" />
                    <div class="muted" style="margin-top:6px;">Current: <?php echo $values['site_logo'] ? '<a href="../' . h($values['site_logo']) . '" target="_blank">View</a> <button type="submit" name="delete_site_logo" value="1" style="margin-left:10px;border:0;background:transparent;color:#c0392b;cursor:pointer;padding:0;">Delete</button>' : 'Not set'; ?></div>
                </div>

                <div class="col-6">
                    <label class="muted" for="site_dp">DP (Display Picture)</label>
                    <input class="input" id="site_dp" name="site_dp" type="file" accept="image/*" />
                    <div class="muted" style="margin-top:6px;">Current: <?php echo $values['site_dp'] ? '<a href="../' . h($values['site_dp']) . '" target="_blank">View</a> <button type="submit" name="delete_site_dp" value="1" style="margin-left:10px;border:0;background:transparent;color:#c0392b;cursor:pointer;padding:0;">Delete</button>' : 'Not set'; ?></div>
                </div>

                <div class="col-6">
                    <label class="muted" for="hero_image_1">Hero Image 1</label>
                    <input class="input" id="hero_image_1" name="hero_image_1" type="file" accept="image/*" />
                    <div class="muted" style="margin-top:6px;">Current: <?php echo $values['hero_image_1'] ? '<a href="../' . h($values['hero_image_1']) . '" target="_blank">View</a> <button type="submit" name="delete_hero_image_1" value="1" style="margin-left:10px;border:0;background:transparent;color:#c0392b;cursor:pointer;padding:0;">Delete</button>' : 'Not set'; ?></div>
                </div>

                <div class="col-6">
                    <label class="muted" for="hero_image_2">Hero Image 2</label>
                    <input class="input" id="hero_image_2" name="hero_image_2" type="file" accept="image/*" />
                    <div class="muted" style="margin-top:6px;">Current: <?php echo $values['hero_image_2'] ? '<a href="../' . h($values['hero_image_2']) . '" target="_blank">View</a> <button type="submit" name="delete_hero_image_2" value="1" style="margin-left:10px;border:0;background:transparent;color:#c0392b;cursor:pointer;padding:0;">Delete</button>' : 'Not set'; ?></div>
                </div>

                <div class="col-6">
                    <label class="muted" for="hero_image_3">Hero Image 3</label>
                    <input class="input" id="hero_image_3" name="hero_image_3" type="file" accept="image/*" />
                    <div class="muted" style="margin-top:6px;">Current: <?php echo $values['hero_image_3'] ? '<a href="../' . h($values['hero_image_3']) . '" target="_blank">View</a> <button type="submit" name="delete_hero_image_3" value="1" style="margin-left:10px;border:0;background:transparent;color:#c0392b;cursor:pointer;padding:0;">Delete</button>' : 'Not set'; ?></div>
                </div>

                <div class="col-6">
                    <label class="muted" for="about_image">About Image</label>
                    <input class="input" id="about_image" name="about_image" type="file" accept="image/*" />
                    <div class="muted" style="margin-top:6px;">Current: <?php echo $values['about_image'] ? '<a href="../' . h($values['about_image']) . '" target="_blank">View</a> <button type="submit" name="delete_about_image" value="1" style="margin-left:10px;border:0;background:transparent;color:#c0392b;cursor:pointer;padding:0;">Delete</button>' : 'Not set'; ?></div>
                </div>

                <div class="col-12" style="margin-top:8px;">
                    <h3>Talent Showcase</h3>
                    <div class="muted">Add talent images. You can remove existing items and upload new ones.</div>
                </div>

                <div class="col-12">
                    <div class="grid" style="margin-top:6px;">
                        <div class="col-12">
                            <?php if (!empty($talent_items)): ?>
                                <div class="muted" style="margin-bottom:8px;">Existing items:</div>
                                <div class="grid">
                                    <?php foreach ($talent_items as $ti): ?>
                                        <div class="col-6">
                                            <?php $tid = (string)($ti['id'] ?? ''); ?>
                                            <div class="muted" style="display:flex;align-items:center;gap:10px;">
                                                <input type="checkbox" id="talent_remove_<?php echo h($tid); ?>" name="talent_remove[]" value="<?php echo h($tid); ?>" />
                                                <label for="talent_remove_<?php echo h($tid); ?>" style="cursor:pointer;">Talent</label>
                                                <?php if (!empty($ti['image'])): ?>
                                                    <a href="../<?php echo h((string)$ti['image']); ?>" target="_blank">View</a>
                                                <?php endif; ?>
                                                <button type="submit" name="talent_remove[]" value="<?php echo h($tid); ?>" style="margin-left:auto;border:0;background:transparent;color:#c0392b;cursor:pointer;padding:0;">Delete</button>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <div class="muted">No talent showcase items yet.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="col-6">
                    <label class="muted" for="talent_images">Talent Images</label>
                    <input class="input" id="talent_images" name="talent_images[]" type="file" accept="image/*" multiple />
                </div>

                <div class="col-12" style="margin-top:8px;">
                    <h3>Events Gallery</h3>
                    <div class="muted">Upload gallery images to display on the website. You can remove existing images and upload new ones.</div>
                </div>

                <div class="col-12">
                    <div class="grid" style="margin-top:6px;">
                        <div class="col-12">
                            <?php if (!empty($event_items)): ?>
                                <div class="muted" style="margin-bottom:8px;">Existing items:</div>
                                <div class="grid">
                                    <?php foreach ($event_items as $ei): ?>
                                        <div class="col-6">
                                            <?php $eid = (string)($ei['id'] ?? ''); ?>
                                            <div class="muted" style="display:flex;align-items:center;gap:10px;">
                                                <input type="checkbox" id="event_remove_<?php echo h($eid); ?>" name="event_remove[]" value="<?php echo h($eid); ?>" />
                                                <label for="event_remove_<?php echo h($eid); ?>" style="cursor:pointer;">Gallery</label>
                                                <?php if (!empty($ei['image'])): ?>
                                                    <a href="../<?php echo h((string)$ei['image']); ?>" target="_blank">View</a>
                                                <?php endif; ?>
                                                <button type="submit" name="event_remove[]" value="<?php echo h($eid); ?>" style="margin-left:auto;border:0;background:transparent;color:#c0392b;cursor:pointer;padding:0;">Delete</button>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <div class="muted">No gallery images yet.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="col-6">
                    <label class="muted" for="event_gallery_images">Upload Gallery Images</label>
                    <input class="input" id="event_gallery_images" name="event_gallery_images[]" type="file" accept="image/*" multiple />
                </div>

                <div class="col-12" style="display:flex;justify-content:flex-end;gap:10px;">
                    <button class="btn btn-primary" type="submit">Save Settings</button>
                    <a class="btn btn-secondary" href="dashboard.php" style="display:inline-flex;align-items:center;justify-content:center;">Back</a>
                </div>
            </div>
        </form>
    </div>
</body>
</html>
